package com.careem.hack.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.careem.hack.model.RiderDetail;
import com.careem.hack.repository.RiderRepository;

@RestController
@RequestMapping("/login")
public class LoginController {

	@Autowired
	private RiderRepository riderRepository;

	@RequestMapping(method = RequestMethod.POST)
	public Map<String, RiderDetail>  login(@RequestBody Map<String, Object> riderMap) {
		String password = riderMap.get("password").toString();
		String contactno = riderMap.get("contactno").toString();
		RiderDetail rider = riderRepository.findOne(contactno);
		if (rider.getPassword().equals(password)) {
			Map<String, RiderDetail > map =new HashMap<String, RiderDetail>();
			map.put("data", rider);
			return map;
	}
		return null;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/{contactno}")
	public RiderDetail getRiderDetails(@PathVariable("contactno") String contactno) {
		return riderRepository.findOne(contactno);
	}
}