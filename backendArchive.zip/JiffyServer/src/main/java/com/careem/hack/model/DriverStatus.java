package com.careem.hack.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "driver_status")
public class DriverStatus {

	@Id
	private String contactno;
	private String lat;
	private String lng;
	private String state;

	public DriverStatus(String contactno, String lat, String lng, String state) {
		super();
		this.contactno = contactno;
		this.lat = lat;
		this.lng = lng;
		this.state = state;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLng() {
		return lng;
	}

	public void setLng(String lng) {
		this.lng = lng;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}