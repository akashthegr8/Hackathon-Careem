package com.careem.hack.apis;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ApiConnector {
	public static StringBuffer callApi(String riderOriginLat, String riderOriginLng, String lat, String lng)
			throws IOException {
		
		URL obj = new URL("https://maps.googleapis.com/maps/api/directions/json?origin=" + riderOriginLat + ","
				+ riderOriginLng + "&destination=" + lat + "," + lng + "&key=AIzaSyD2b_RrlfpIl5-IpodPdxe4vGoGYGRY4J4");
		System.out.println(obj.toString());
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		return response;
	}
}
