package com.careem.hack.controller;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.careem.hack.apis.ApiConnector;
import com.careem.hack.model.CurrentDetail;
import com.careem.hack.model.DriverStatus;
import com.careem.hack.repository.CurrentDetailRepository;
import com.careem.hack.repository.DriverStateRepository;

@RestController
@RequestMapping("/book")
public class BookCabController {

	@Autowired
	private DriverStateRepository driverStateRepository;
	@Autowired
	private CurrentDetailRepository currentDetailRepository;

	@RequestMapping(method = RequestMethod.POST)
	public Map<String, Object> bookCab(@RequestBody Map<String, Object> riderDetails) throws IOException {

		String riderOriginLat = riderDetails.get("rideroriginlat").toString();
		String riderOriginLng = riderDetails.get("rideroriginlng").toString();
		String riderDestLat = riderDetails.get("riderdestlat").toString();
		String riderDestLng = riderDetails.get("riderdestlng").toString();
		String riderPaymentMode = riderDetails.get("paymentmode").toString();
		String riderContactNo = riderDetails.get("contactno").toString();
		
		List<DriverStatus> allDrivers = driverStateRepository.findAll();
		float minDistance = 1000000.0f;
		float minDuration = 0f;
		DriverStatus selected = null;
		for (DriverStatus d : allDrivers) {
			if (d.getState().equals("available")) {
				String lat = d.getLat();
				String lng = d.getLng();
				System.out.println(d.getLat() + "   " + d.getLng());
				System.out.println(riderOriginLat + "   " + riderOriginLng);
				StringBuffer response = ApiConnector.callApi(riderOriginLat, riderOriginLng, lat, lng);
				
				JSONObject jsonObject = new JSONObject(response.toString());
				try{
				JSONArray routes = jsonObject.getJSONArray("routes");
				JSONArray legs = routes.getJSONObject(0).getJSONArray("legs");
				String distance = legs.getJSONObject(0).getJSONObject("distance").get("value").toString();
				String duration = legs.getJSONObject(0).getJSONObject("duration").get("value").toString();
				
				if(minDistance > Float.parseFloat(distance)){
					minDistance = Float.parseFloat(distance);
					minDuration = Float.parseFloat(duration);
					selected = d;
				}
				}catch(Exception e){
					//e.printStackTrace();
				}
			}
		}
		
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		
		if(selected == null)
			response.put("message", "No Drivers Nearby");
		else{
			response.put("message", "Cab Booked");
			float riderEstimatedCost = (minDistance/1000) * 6 + minDuration/60; 
			CurrentDetail currentDetail = new CurrentDetail(selected.getContactno(), riderContactNo, riderOriginLat, riderOriginLng, riderDestLat, riderDestLng, riderEstimatedCost+"", minDistance+"", minDuration+"", riderPaymentMode, selected.getLat(), selected.getLng());
			currentDetailRepository.save(currentDetail);
			selected.setState("onride");
			driverStateRepository.save(selected);
			response.put("booked", currentDetail);
			
		}
		
		return response;
	}
	

	@RequestMapping(method = RequestMethod.GET, value = "/{rideid}")
	public CurrentDetail getBookingDetails(@PathVariable("rideid") String rideid) {
		return currentDetailRepository.findOne(rideid);
	}
}