package com.careem.hack.controller;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.careem.hack.apis.ApiConnector;
import com.careem.hack.model.CurrentDetail;
import com.careem.hack.model.DriverStatus;
import com.careem.hack.repository.CurrentDetailRepository;
import com.careem.hack.repository.DriverStateRepository;

@RestController
@RequestMapping("/update")
public class LocationUpdateController {

	@Autowired
	private DriverStateRepository driverStateRepository;
	@Autowired
	private CurrentDetailRepository currentDetailRepository;

	@RequestMapping(method = RequestMethod.POST)
	public Map<String, Object> locationUpdate(@RequestBody Map<String, Object> driverStatus) throws IOException {

		DriverStatus driverState = new DriverStatus(driverStatus.get("contactno").toString(),
				driverStatus.get("lat").toString(), driverStatus.get("lng").toString(),
				driverStatus.get("state").toString());
		driverStateRepository.save(driverState);
		
		List<CurrentDetail> current = currentDetailRepository.findAll();
		for(CurrentDetail cr : current){
			
			if(cr.getDrivercontactno().equals(driverState.getContactno()))
			{
				System.out.println(cr.getDrivercontactno());
				System.out.println(driverState.getContactno());
				cr.setDriverlat(driverState.getLat());
				cr.setDriverlng(driverState.getLng());
				StringBuffer response = ApiConnector.callApi(cr.getRideroriginlat(), cr.getRideroriginlng(), driverState.getLat(), driverState.getLng());
				System.out.println(response);
				JSONObject jsonObject = new JSONObject(response.toString());
				JSONArray routes = jsonObject.getJSONArray("routes");
				JSONArray legs = routes.getJSONObject(0).getJSONArray("legs");
				String distance = legs.getJSONObject(0).getJSONObject("distance").get("value").toString();
				String duration = legs.getJSONObject(0).getJSONObject("duration").get("value").toString();
				cr.setDistance(distance);
				cr.setDuration(duration);
				
				currentDetailRepository.save(cr);
				Map<String, Object> responseData = new LinkedHashMap<String, Object>();
				responseData.put("book", cr);
				return responseData;
			}
		}
		return null;
		
	}

	@RequestMapping(method = RequestMethod.GET)
	public List<DriverStatus> getcurrentDetail() {
		return driverStateRepository.findAll();
	}
}