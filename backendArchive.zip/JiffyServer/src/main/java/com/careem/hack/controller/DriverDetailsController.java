package com.careem.hack.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.careem.hack.model.DriverDetail;
import com.careem.hack.model.DriverStatus;
import com.careem.hack.repository.DriverRepository;
import com.careem.hack.repository.DriverStateRepository;

@RestController
@RequestMapping("/driverdetails")
public class DriverDetailsController {

	@Autowired
	private DriverRepository driverRepository;
	@Autowired
	private DriverStateRepository driverStateRepository;

	@RequestMapping(method = RequestMethod.POST)
	public Map<String, Object> createdriver(@RequestBody Map<String, Object> driverMap) {
		DriverDetail driverDetail = new DriverDetail(driverMap.get("useremail").toString(),
				driverMap.get("username").toString(), driverMap.get("password").toString(),
				driverMap.get("contactno").toString(), driverMap.get("ssnno").toString(),
				driverMap.get("cabno").toString(), driverMap.get("rating").toString()

		);

		DriverStatus driverStatus = new DriverStatus(driverMap.get("contactno").toString(),
				driverMap.get("lat").toString(), driverMap.get("lng").toString(), driverMap.get("state").toString());

		driverRepository.save(driverDetail);
		driverStateRepository.save(driverStatus);
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		response.put("message", "driver created successfully");
		response.put("book", driverDetail);
		return response;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/{contactno}")
	public DriverDetail getdriverDetails(@PathVariable("contactno") String contactno) {
		return driverRepository.findOne(contactno);
	}
}