package com.careem.hack.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.careem.hack.model.DriverDetail;
public interface DriverRepository extends MongoRepository<DriverDetail, String>{
}
