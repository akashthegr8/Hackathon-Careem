package com.careem.hack.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "driver_details")
public class DriverDetail {

	private String useremail;
	private String username;
	private String password;
	@Id
	private String contactno;
	private String ssnno;
	private String cabno;
	private String rating;

	public DriverDetail(String useremail, String username, String password, String contactno, String ssnno,
			String cabno, String rating) {
		super();
		this.useremail = useremail;
		this.username = username;
		this.password = password;
		this.contactno = contactno;
		this.ssnno = ssnno;
		this.cabno = cabno;
		this.rating = rating;
	}

	public String getSsnno() {
		return ssnno;
	}

	public void setSsnno(String ssnno) {
		this.ssnno = ssnno;
	}

	public String getCabno() {
		return cabno;
	}

	public void setCabno(String cabno) {
		this.cabno = cabno;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public DriverDetail() {
	}

	public String getUseremail() {
		return useremail;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

}