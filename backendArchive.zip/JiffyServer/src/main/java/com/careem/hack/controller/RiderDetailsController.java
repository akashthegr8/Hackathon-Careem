package com.careem.hack.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.careem.hack.model.RiderDetail;
import com.careem.hack.repository.RiderRepository;

@RestController
@RequestMapping("/riderdetails")
public class RiderDetailsController {

	@Autowired
	private RiderRepository riderRepository;

	@RequestMapping(method = RequestMethod.POST)
	public Map<String, Object> createRider(@RequestBody Map<String, Object> riderMap) {
		RiderDetail riderDetail = new RiderDetail(riderMap.get("useremail").toString(),
				riderMap.get("username").toString(), riderMap.get("password").toString(),
				riderMap.get("contactno").toString());

		riderRepository.save(riderDetail);
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		response.put("message", "Rider created successfully");
		response.put("book", riderDetail);
		return response;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/{contactno}")
	public RiderDetail getRiderDetails(@PathVariable("contactno") String contactno) {
		return riderRepository.findOne(contactno);
	}
}