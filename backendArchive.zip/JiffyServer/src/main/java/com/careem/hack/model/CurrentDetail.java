package com.careem.hack.model;

import java.util.UUID;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "current_ride")
public class CurrentDetail {
	@Id
	private String rideid;
	
	private String drivercontactno;
	private String ridercontactno;
	private String rideroriginlat;
	private String rideroriginlng;
	private String riderdestlat;
	private String riderdestlng;
	private String estimatedcost;
	private String distance;
	private String duration;
	private String paymentmode;
	private String ridestatus;
	private String driverlat;
	private String driverlng;
	
	
	public CurrentDetail(String drivercontactno, String ridercontactno, String rideroriginlat, String rideroriginlng,
			String riderdestlat, String riderdestlng, String estimatedcost, String distance, String duration,
			String paymentmode, String driverlat, String driverlng) {
		super();
		this.ridestatus = "ongoing";
		this.rideid = UUID.randomUUID().toString();
		this.drivercontactno = drivercontactno;
		this.ridercontactno = ridercontactno;
		this.rideroriginlat = rideroriginlat;
		this.rideroriginlng = rideroriginlng;
		this.riderdestlat = riderdestlat;
		this.riderdestlng = riderdestlng;
		this.estimatedcost = estimatedcost;
		this.distance = distance;
		this.duration = duration;
		this.paymentmode = paymentmode;
		this.driverlat = driverlat;
		this.driverlng = driverlng;
		
	}
	public String getRideid() {
		return rideid;
	}

	public void setRideid(String rideid) {
		this.rideid = rideid;
	}

	public String getDriverlat() {
		return driverlat;
	}

	public void setDriverlat(String driverlat) {
		this.driverlat = driverlat;
	}

	public String getDriverlng() {
		return driverlng;
	}

	public void setDriverlng(String driverlng) {
		this.driverlng = driverlng;
	}

	public String getDrivercontactno() {
		return drivercontactno;
	}

	public void setDrivercontactno(String drivercontactno) {
		this.drivercontactno = drivercontactno;
	}
	
	public String getRidestatus() {
		return ridestatus;
	}
	
	public void setRidestatus(String ridestatus) {
		this.ridestatus = ridestatus;
	}

	public String getRidercontactno() {
		return ridercontactno;
	}

	public void setRidercontactno(String ridercontactno) {
		this.ridercontactno = ridercontactno;
	}

	public String getRideroriginlat() {
		return rideroriginlat;
	}

	public void setRideroriginlat(String rideroriginlat) {
		this.rideroriginlat = rideroriginlat;
	}

	public String getRideroriginlng() {
		return rideroriginlng;
	}

	public void setRideroriginlng(String rideroriginlng) {
		this.rideroriginlng = rideroriginlng;
	}

	public String getRiderdestlat() {
		return riderdestlat;
	}

	public void setRiderdestlat(String riderdestlat) {
		this.riderdestlat = riderdestlat;
	}

	public String getRiderdestlng() {
		return riderdestlng;
	}

	public void setRiderdestlng(String riderdestlng) {
		this.riderdestlng = riderdestlng;
	}

	public String getEstimatedcost() {
		return estimatedcost;
	}

	public void setEstimatedcost(String estimatedcost) {
		this.estimatedcost = estimatedcost;
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getPaymentmode() {
		return paymentmode;
	}

	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}
}
