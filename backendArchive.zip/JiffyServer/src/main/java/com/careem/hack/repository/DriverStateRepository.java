package com.careem.hack.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.careem.hack.model.DriverStatus;
public interface DriverStateRepository extends MongoRepository<DriverStatus, String>{
}
