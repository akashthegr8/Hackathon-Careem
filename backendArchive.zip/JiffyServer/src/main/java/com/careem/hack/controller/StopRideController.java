package com.careem.hack.controller;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.careem.hack.model.CurrentDetail;
import com.careem.hack.model.DriverStatus;
import com.careem.hack.repository.CurrentDetailRepository;
import com.careem.hack.repository.DriverStateRepository;

@RestController
@RequestMapping("/stopride")
public class StopRideController {

	@Autowired
	private DriverStateRepository driverStateRepository;
	@Autowired
	private CurrentDetailRepository currentDetailRepository;

	@RequestMapping(method = RequestMethod.POST)
	public Map<String, Object> stopRide(@RequestBody Map<String, Object> driverStatus) throws IOException {

		DriverStatus driverState = new DriverStatus(driverStatus.get("contactno").toString(),
				driverStatus.get("lat").toString(), driverStatus.get("lng").toString(),
				driverStatus.get("state").toString());

		driverState.setState("available");
		driverStateRepository.save(driverState);
		
		List<CurrentDetail> current = currentDetailRepository.findAll();
		for(CurrentDetail cr : current){
			
			if(cr.getDrivercontactno().equals(driverState.getContactno()))
			{

				cr.setRidestatus("completed");
				
				currentDetailRepository.save(cr);
				Map<String, Object> responseData = new LinkedHashMap<String, Object>();
				responseData.put("book", cr);
				return responseData;
			}
		}
		return null;
		
	}
	@RequestMapping(method = RequestMethod.GET, value = "/{contactno}")
	public DriverStatus getDriverStatus(@PathVariable("contactno") String contactno) {
		return driverStateRepository.findOne(contactno);
	}
}