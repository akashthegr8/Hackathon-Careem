package com.careem.hack.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.careem.hack.model.RiderDetail;
public interface RiderRepository extends MongoRepository<RiderDetail, String>{
}
